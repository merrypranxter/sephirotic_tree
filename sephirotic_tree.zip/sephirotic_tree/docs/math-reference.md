# Math Reference: sephirotic_tree

> TODO: add mathematical foundations, equations, and reference values.
