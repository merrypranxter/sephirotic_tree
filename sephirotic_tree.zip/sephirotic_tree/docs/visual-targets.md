# Visual Targets: sephirotic_tree

> TODO: describe desired visual output, color palettes, and animation behavior.
