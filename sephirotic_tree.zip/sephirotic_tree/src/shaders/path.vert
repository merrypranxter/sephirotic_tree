// TODO: path.vert
