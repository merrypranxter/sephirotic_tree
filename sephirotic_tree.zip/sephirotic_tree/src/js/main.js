// Tree of Life renderer and interaction loop
