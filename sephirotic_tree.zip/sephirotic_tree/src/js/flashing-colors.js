// King/Queen/Emperor color scale cycling
