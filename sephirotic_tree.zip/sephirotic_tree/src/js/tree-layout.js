// Sephirot coordinates and path definitions
