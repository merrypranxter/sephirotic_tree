// Animated curve paths between sephirot
