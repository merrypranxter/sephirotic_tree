# sephirotic_tree

> 10 sephirot. 22 paths. the tree of life as luminous divine network.

A complete Kabbalistic Tree of Life rendered as an interactive network visualization. Each of the 10 divine emanations (sephirot) is a glowing sphere with planetary correspondence. The 22 paths between them carry animated energy flows. Flashing colors cycle through king/queen/emperor scales.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Pulse lightning flash (Kether → Malkuth) |
| `S` | Toggle serpent path animation |
| `F` | Cycle flashing color scale |
| `P` | Show/hide planetary glyphs |
| `H` | Show/hide Hebrew letter paths |
| `1–10` | Highlight specific sephira |

## Named Regimes

- **Flashing Colors** — King/Queen/Emperor scale color cycling
- **Lightning Flash** — Zigzag descent from Crown to Kingdom
- **Serpent Path** — Back-and-forth route through the tree
- **Planetary Hours** — Sephira glow intensity by planetary hour
- **Path Working** — Meditative walk along selected path

## The Math

Standard GD layout coordinates (normalized):
- Kether (1): (0.5, 0.95)
- Chokmah (2): (0.75, 0.78)
- Binah (3): (0.25, 0.78)
- ...through Malkuth (10): (0.5, 0.05)

22 paths connect specific pairs (e.g., Path 11: Kether-Chokmah). Each path has a Hebrew letter, tarot correspondence, and color.

Color scales (RGB):
- King Scale: divine/active (Kether=white, Chokmah=grey, Binah=black...)
- Queen Scale: manifest/passive (complementary/opposite)
- Emperor Scale: synthesis/bridge

## Acknowledgments

Golden Dawn tradition, Dion Fortune's *The Mystical Qabalah*, Aryeh Kaplan's *Sefer Yetzirah*.
